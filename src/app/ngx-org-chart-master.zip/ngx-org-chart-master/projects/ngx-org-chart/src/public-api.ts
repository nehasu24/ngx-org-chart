/*
 * Public API Surface of ngx-org-chart
 */

export * from './lib/ngx-org-chart/ngx-org-chart.module';
